#!/system/bin/sh
# Script untuk mendeteksi chipset

ui_print "Checking device compatibility..."

# Deteksi chipset
chipset=$(getprop ro.board.platform)

case "$chipset" in
    "msm"*)
        ui_print "Detected Snapdragon chipset."
        ;;
    "mt"*)
        ui_print "Detected MediaTek chipset."
        ;;
    *)
        ui_print "Unsupported chipset: $chipset"
        abort
        ;;
esac

# Lanjutkan instalasi
ui_print "Installing module..."
