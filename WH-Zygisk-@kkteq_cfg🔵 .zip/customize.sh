  ui_print "_____________________________________________________"
  ui_print "           ⚡ Wallhack Pubgm 3.6 ⚡         "
busybox sleep 1
  ui_print "                   "
  ui_print "                   "
busybox sleep 1
  ui_print " Created By : Only ChenkZ"
  ui_print " Telegram : @Only_ChenkZ"
busybox sleep 1
  ui_print "⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⣀⡀⢀⢀⢀⢀⢀⢀⢀⢀"
busybox sleep 1
  ui_print "⢀⢀⢀⢀⢀⢀⢀⡤⠒⠋⠉⠁⢀⠉⠉⠑⠲⢄⡀⢀⢀⢀"
busybox sleep 1
  ui_print "⢀⢀⢀⢀⢀⠔⢁⡠⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⠉⢢⡀⢀"
busybox sleep 1
  ui_print "⢀⢀⢀⢠⠃⣴⡇⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⠱⡄"
  ui_print "⢀⢀⢠⠃⢀⣿⣧⣀⢀⢀⣀⢀⢀⢀⢀⢀⢀⢀⢀⠈⣆⠹⡀"
busybox sleep 1
  ui_print "⢀⢀⡸⢀⢀⠹⣶⣿⣿⣿⣿⣿⣶⣶⣶⣤⡀⢀⢀⣴⡿⢀⡇"
  ui_print ". ⢀⡇⢀⢀⢀⠤⣾⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⢀⡇"
busybox sleep 1
  ui_print "⢀.⢱⢀⣠⣤⣶⣿⣿⣧⣉⣿⣿⡟⣃⣿⢿⡿⢀⢀⢀⢀⡇"
  ui_print "⢀⢀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⢀⢀⢀⢀⢀⡰⠁"
busybox sleep 1
  ui_print "⢀⢀⢀⠘⣿⣿⣿⣿⣿⣏⡀⢀⣸⣿⣿⢀⢀⢀⢀⢀⡰⠃"
  ui_print "⢀⢀⢀⢀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⡏⢀⢀⢀⣠⠞⠁⢀"
  busybox sleep 1
  ui_print "⢀⢀⢀⢀⢀⢀⠈⠙⠿⢿⣿⣿⣿⣿⣇⡠⠔⠊⠁⢀⢀⢀"
  ui_print "⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀⢀"
  busybox sleep 1
  ui_print "                 Loading..."
  busybox sleep 1
  ui_print "                 Installing..."
  ui_print "                 Wait.."
  busybox sleep 1
  ui_print " Done!!!! "
  busybox sleep 1
  ui_print "___________________● REBOOT DEVICE●__________________"
  
  
  
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
