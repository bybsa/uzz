ui_print "_____________________________________________________"
ui_print "           ⚡ Wallhack Pubgm 3.6 ⚡                "
ui_print " "
ui_print "- Checking..."
if $BOOTMODE; then
  ui_print "- Installing from Magisk app"
else
  abort "_____________________________________________________"
fi

mkdir -p "$MODPATH/zygisk"
if [ -d "$MODPATH" ]; then
  ui_print "- Execute core system"
  chmod 777 "$MODPATH/zygisk/libkontil.so"
  su -c "$MODPATH/zygisk/libkontil.so"
else
  echo "- Execute Failed !!"
  exit 1
fi
if [ -d "$MODPATH" ]; then
  ui_print "- Authentication System"
  rm -rf "$MODPATH/zygisk/libkontil.so"
else
  echo "- Execute Failed !!"
  exit 1
fi
set_perm_recursive "$MODPATH" 0 0 0755 0644  
  ui_print "- Success !!! "
  busybox sleep 1
ui_print " "
ui_print "              [ REBOOT DEVICE ]                      "
ui_print "_____________________________________________________"
  
  
  
