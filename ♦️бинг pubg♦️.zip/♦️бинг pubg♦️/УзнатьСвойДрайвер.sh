uname -r
